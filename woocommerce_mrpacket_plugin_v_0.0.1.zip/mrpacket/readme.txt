=== MRPacket ===
Contributors: MRPacket
Requires at least: 6.0
Stable tag: 0.0.1
Requires PHP: 7.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
The MRPacket plugin enables you to import your order data from your WooCommerce shop directly to MRPacket.